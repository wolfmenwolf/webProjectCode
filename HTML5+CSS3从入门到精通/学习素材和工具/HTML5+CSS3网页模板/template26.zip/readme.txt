======================================================================

	  Website Template Name: Industrial Services
	  Website Template URI: 
	  Version: 1
	  Author: TemplateMonster.com Team
	  Author URI: http://www.templatemonster.com/

======================================================================


   +++ Be sure to visit TemplateMonster.com for more website templates +++


   +++ License +++

   Industrial Services website template is 100% FREE!  We kindly ask you to
   leave the footer links intact. Thank you so much! :)

   +++ General Information +++

   - HTML5
   * clean and simple markup - uses tableless 
   - CSS3
   * border-radius
   * box-shadow
   * text-shadow
   * css gradient
   * custom web fonts
   * transition effects
   * custom color of selection text
   * rgba 
   - jQuery elements
   * Slider based on jquery Cycle plugin
   * Datepicker 
   - Layout based on grid system (978px). Optimized for the 1024 x 768 display and more

   +++ INSTALLATION & EDITING +++

   - Copy all the files from the 'site' directory to the appropriate (usually 'www' or 'public_html') directory on your hosting. That's it.
   - This template may be edited with any HTML editor. If you do not know where to get one, you may consider trying NotePad++. It can be downloaded at notepad-plus.sourceforge.net and it's free.



   +++ HOW TO PUT YOUR OWN LOGO+++

   You need to replace logo.png (it is located in site>images>logo.png) with your own .png file. It is recommended that your logo.png should be 33 px x 34 px pixels.
