Cufon.replace('#header .nav li a', { fontFamily: 'Myriad Pro', textShadow: '#fff 1px 1px', hover:true });
Cufon.replace('h1, h2, h3', { fontFamily: 'Myriad Pro'});