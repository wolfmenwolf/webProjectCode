$(function(){
	// faded slider
	$("#faded").faded({
		speed: 500,
		crossfade: true,
		autoplay: 5000,
		autorestart: 3000,
		autopagination:false
	});
})