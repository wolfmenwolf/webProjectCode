Cufon.replace('#slogan, .text2, h2', { fontFamily: 'Myriad Pro It', hover:true });
Cufon.replace('.text1', { fontFamily: 'Myriad Pro', hover:true });
Cufon.replace('#menu a', { fontFamily: 'Myriad Pro It', hover:true, textShadow:'rgba(0, 0, 0, .4) 1px 1px' });

