<?php get_header(); ?>

		<h2>Error 404 - Not Found</h2>
		<p>Sorry, but you are looking for something that isn't here.</p>

<?php get_sidebar(); ?>
<?php get_footer(); ?>