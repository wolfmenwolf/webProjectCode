Orange Flower WordPress Theme
-----------------------------

You can specify the following options on a 'Appearance -> Orange Flower Theme Options' page in admin area:

- main layout position;
- sidebars position.


Changelog:
----------

1.2 - added a theme options page in admin panel.
		- added breadcrums navigation.

1.1.2 - initial version.


--
Regards, Dimox
http://dimox.net