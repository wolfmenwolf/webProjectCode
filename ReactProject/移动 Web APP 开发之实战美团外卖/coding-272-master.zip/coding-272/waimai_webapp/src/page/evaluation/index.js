import React from 'react';
import ReactDom from 'react-dom';


import Container from './Main/Container.jsx';


ReactDom.render(
    <Container />,
    document.getElementById('root')
);