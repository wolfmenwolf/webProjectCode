module.exports = {
    TABKEY: {
        home: 'home',
        order: 'order',
        my: 'my'
    }
};