module.exports = {
    TABKEY: {
        menu: 'menu',
        comment: 'comment',
        restanurant: 'restanurant'
    }
}