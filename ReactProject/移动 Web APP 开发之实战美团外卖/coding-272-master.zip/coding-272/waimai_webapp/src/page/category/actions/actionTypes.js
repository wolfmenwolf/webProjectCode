export const CHANGE_TAB = 'CHANGE_TAB';
export const GET_FILTER_DATA = 'GET_FILTER_DATA';
export const CHANGE_FILTER = 'CHANGE_FILTER';
export const GET_LIST_DATA = 'GET_LIST_DATA';