module.exports = {
    TABKEY: {
        cate: 'cate',
        type: 'type',
        filter: 'filter'
    }
};