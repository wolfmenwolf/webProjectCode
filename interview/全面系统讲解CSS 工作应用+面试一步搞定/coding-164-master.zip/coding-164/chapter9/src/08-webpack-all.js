const component = require('./07-webpack-component');

component.init(document.querySelector('#component'));
