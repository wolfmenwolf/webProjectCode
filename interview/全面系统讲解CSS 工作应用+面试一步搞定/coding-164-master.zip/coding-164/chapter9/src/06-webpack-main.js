require('./06-webpack-css.css');


console.log('hello');
