const component = require('./07-webpack-component');

document.addEventListener('DOMContentLoaded', function(){
    component.init(document.querySelector('#component'));
});
