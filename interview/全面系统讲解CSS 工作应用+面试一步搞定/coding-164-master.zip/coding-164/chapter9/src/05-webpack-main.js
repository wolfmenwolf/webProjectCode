var module = require('./05-webpack-module.js');

module.say();
