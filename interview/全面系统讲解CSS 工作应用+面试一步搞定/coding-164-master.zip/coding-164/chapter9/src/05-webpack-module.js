module.exports = {
    say: function(){
        console.log('hello from module');
    }
}
