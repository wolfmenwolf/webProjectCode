"use strict";//脚本文件第一行
function sum(x) {
  "use strict";//函数内第一行
  return x;
}
sum(10);
