function sum(x) {
	return x;
}
var x=1, y=2;
var total = sum
(x+y)
//console.log(total);
//相当于
var total = sum(x+y);
//console.log(total);