console.log(parseFloat("01.25.1")); 	//1.25
console.log(parseFloat("1e+2")); 		//100
console.log(parseFloat("0xA")); 		//0
