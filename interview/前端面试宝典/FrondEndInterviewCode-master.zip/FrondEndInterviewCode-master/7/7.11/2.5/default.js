function func(name) {
    return name;
}
function func(name, age) {
    return age;
}
func("strick", 28);		//28