// function func1() {
//     age = 28; 	//全局变量
// }
// function func2() {
//     "use strict"; 	//严格模式
//     age = 28; 	//Uncaught ReferenceError
// }
// func2();