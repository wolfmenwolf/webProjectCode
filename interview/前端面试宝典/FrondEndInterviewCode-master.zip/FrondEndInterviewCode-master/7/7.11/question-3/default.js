var age = 30;
function func() {
    if (!age) {
        var age = 28;
    }
    console.log(age);
}
func();