var count = 0;
setTimeout(function() {
    count++; 	//1
}, 0);