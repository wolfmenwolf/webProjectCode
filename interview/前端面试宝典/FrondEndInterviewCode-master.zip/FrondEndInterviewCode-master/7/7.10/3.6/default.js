var arr = [1, 2, 3, 4, 5, 6];
console.log(arr.indexOf(3)); 		//2
console.log(arr.indexOf(3, 3)); 		//-1
console.log(arr.indexOf(3, -3)); 	//-1
console.log(arr.lastIndexOf(3)); 	//2
console.log(arr.lastIndexOf(3, 3)); 	//2
console.log(arr.lastIndexOf(3, -3)); //2

