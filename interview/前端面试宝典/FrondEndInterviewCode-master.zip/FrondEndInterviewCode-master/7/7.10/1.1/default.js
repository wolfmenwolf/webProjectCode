var result1 = new Array();
var result2 = new Array(10);
// var result2 = new Array(-1);
var result3 = new Array(1, 2, 3);
console.log(result1);
console.log(result2);
console.log(result3);

