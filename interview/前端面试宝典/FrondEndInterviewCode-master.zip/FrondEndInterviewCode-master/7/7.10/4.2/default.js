var str = "12345";
str[0]; 	 //1
str[1]; 	 //2
str.length;  //5
str.push(6); //抛出异常