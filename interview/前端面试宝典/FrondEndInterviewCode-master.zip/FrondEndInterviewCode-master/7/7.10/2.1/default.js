var arr = [1, 2, 3, 4, 5],
    index = 0;
console.log(arr[0]); 			//1
console.log(arr[index + 2]);	//3
console.log(arr[10]); 			//undefined
