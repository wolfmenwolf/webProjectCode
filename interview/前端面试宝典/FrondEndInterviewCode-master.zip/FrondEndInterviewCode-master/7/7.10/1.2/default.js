var item = 1;
var arr1 = [1, 2, 3]; 		//稠密数组
var arr2 = [1, item + 1]; 	//元素是表达式
var arr3 = [1, , 3]; 		//稀疏数组
console.log(arr1);
console.log(arr2);
console.log(arr3);

