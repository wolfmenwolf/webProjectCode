// for(var i=0; i<3; i++) {}
// console.log(i); 	//3

(function() {
  for (var i = 0; i < 3; i++) {}
})();
//console.log(i); //抛出未定义的异常