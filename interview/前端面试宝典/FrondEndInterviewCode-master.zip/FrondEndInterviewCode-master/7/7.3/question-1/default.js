//console.log(3.toFixed(2));//无效语法
console.log(3..toFixed(2));//3.00
//console.log(3.1..toFixed(2));//无效语法
console.log(3 .toFixed(2));//3.00
console.log(3.1465.toFixed(2));//3.15