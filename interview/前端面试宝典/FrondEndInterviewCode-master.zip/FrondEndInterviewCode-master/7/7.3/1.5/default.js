console.log("xyz" - 1);	//NaN
console.log(0 / 0);		//NaN

console.log("isNaN()");
console.log(isNaN(NaN));	//true
console.log(isNaN(1));		//false
console.log(isNaN("xyz"));	//true