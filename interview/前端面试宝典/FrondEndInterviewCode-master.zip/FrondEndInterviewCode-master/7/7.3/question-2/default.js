var result = "pwstrick".split("").reverse().join("");
console.log(result);//"kcirtswp"
