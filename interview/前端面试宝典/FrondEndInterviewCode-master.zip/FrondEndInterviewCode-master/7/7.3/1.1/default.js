var num10 = 10;		//十进制
var num8 = 012;		//八进制
var num16 = 0xA;	//十六进制