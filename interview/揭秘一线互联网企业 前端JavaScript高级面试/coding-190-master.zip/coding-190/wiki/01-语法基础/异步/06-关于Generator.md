# 关于 Generator

为何不深入讲解 Generator ？

- 原理比较复杂，语法比较费解
- 不是为解决异步而创建的，恰巧被用来解决异步而已
- 有更好的替代方案 async/await