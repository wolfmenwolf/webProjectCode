export default {
    a: 100
}