export function fn1() {
    alert('fn1')
}

export function fn2() {
    alert('fn2')
}