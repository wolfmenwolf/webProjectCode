<ul>
    {
        list.map((item, index) => {
            return <li key={index}>{item}</li>
        })
    }
</ul>