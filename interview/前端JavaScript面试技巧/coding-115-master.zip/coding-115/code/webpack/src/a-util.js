var util = require('./util.js')

module.exports = {
    aGetFormatDate: function (dt) {
        return util.getFormatDate(dt, 2)
    }
}
