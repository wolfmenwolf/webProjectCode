var aUtil = require('./a-util.js')

var dt = new Date()
console.log( aUtil.aGetFormatDate(dt) )
